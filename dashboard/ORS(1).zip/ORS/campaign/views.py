from models import Campaign
from django.contrib.auth.models import User
from rest_framework import status
from rest_framework.authtoken.models import Token
from rest_framework.decorators import api_view
from rest_framework.response import Response
from django.contrib.auth import login, logout
from django.shortcuts import render
import json
from django.views.decorators.csrf import csrf_exempt
# Create your views here.


def index(request):
    return render(request, 'index.html')


@csrf_exempt
@api_view(['POST'])
def login_view(request):
    if request.method == 'POST':
        try:
            str_response = request.body.decode('utf-8')
            data = json.loads(str_response)
            username = data.get('username')
            password = data.get('password')
            if not User.objects.filter(username=username).exists():
                user = User.objects.create_user(username=username, password=password)
            else:
                user = User.objects.get(username=username)
            login(request, user)
            token = Token.objects.get_or_create(user=user)
            # print(token[0])
            response_data = {'token': str(token[0]),
                             'message': 'User logged in successfully!!!',
                             'user_id': request.user.id,
                             'username': request.user.username,
                             'email': request.user.username}
            return Response(data={'data':response_data}, status=status.HTTP_200_OK)
        except Exception as e:
            print(str(e))
            response_data = {'message': 'Something went wrong. Please try later'}
            return Response(data=response_data, status=status.HTTP_500_INTERNAL_SERVER_ERROR)
    else:
        return Response(status=status.HTTP_405_METHOD_NOT_ALLOWED)


@csrf_exempt
@api_view(['POST'])
def logout_view(request):
    try:
        if request.user.is_authenticated():
            request.user.auth_token.delete()
            logout(request)
            response_data = {'message': 'Logged out successfully!!!'}
            return Response(data=response_data, status=status.HTTP_200_OK)
        else:
            return Response(data={'message': "Session is invalid."},
                            status=status.HTTP_401_UNAUTHORIZED)
    except Exception as e:
        print(str(e))
        return Response(data={'message': 'Something went wrong. Please try again.'},
                        status=status.HTTP_401_UNAUTHORIZED)


@csrf_exempt
@api_view(['GET', 'POST', 'PUT'])
def campaign(request, campaign_id=None):
    try:
        if request.user.is_authenticated():
            if request.method == 'GET':
                if campaign_id is None:
                    campaign_list = Campaign.objects.filter(owner=request.user)
                else:
                    campaign_list = Campaign.objects.filter(owner=request.user, pk=campaign_id)
                result = []
                for each in campaign_list:
                    each_dict = dict()
                    each_dict['name'] = each.name
                    each_dict['id'] = each.id
                    each_dict['name'] = each.name
                    each_dict['category'] = each.category
                    each_dict['period'] = each.period
                    each_dict['money'] = each.money
                    each_dict['conversion_ratio'] = each.conversion_ratio
                    result.append(each_dict)
                return Response(data={'data': result,
                                      'message': 'Campaigns fetched successfully!!!'},
                                status=status.HTTP_200_OK)
            elif request.method == 'POST':
                str_response = request.body.decode('utf-8')
                data = json.loads(str_response)
                Campaign.create(data, request.user)
                return Response(data={'message': 'Campaign has been created successfully!!!'},
                                status=status.HTTP_201_CREATED)
            elif request.method == 'PUT':
                str_response = request.body.decode('utf-8')
                data = json.loads(str_response)
                Campaign.update(data, request.user)
                return Response(data={'message': 'Campaign has been updated successfully!!!'},
                                status=status.HTTP_202_ACCEPTED)
            else:
                Response(data={'message': 'Method not allowed'},
                         status=status.HTTP_405_METHOD_NOT_ALLOWED)
        else:
            return Response(data={'message': 'You do not have permission to perform this action'},
                            status=status.HTTP_401_UNAUTHORIZED)
    except Exception as e:
        print(str(e))
        return Response(data={'message': 'Something went wrong. Please try again.'},
                        status=status.HTTP_401_UNAUTHORIZED)