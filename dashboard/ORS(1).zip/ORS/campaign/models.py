from django.db import models
from django.contrib.auth.models import User


# Create your models here.
class Campaign(models.Model):
    name = models.CharField(default="", max_length=128)
    owner = models.ForeignKey(User, on_delete=models.CASCADE, null=True)
    money = models.IntegerField(default=0)
    category = models.CharField(default="", max_length=64)
    conversion_ratio = models.IntegerField(default=0)
    period = models.CharField(default="", max_length=64)
    created_at = models.DateTimeField(auto_now=False, auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True, auto_now_add=False)

    @classmethod
    def create(cls, campaign_dict, user):
        new_campaign = cls()
        new_campaign.name = campaign_dict['name']
        new_campaign.category = campaign_dict['category']
        new_campaign.conversion_ratio = campaign_dict['conversion_ratio']
        new_campaign.period = campaign_dict['period']
        new_campaign.money = campaign_dict['money']
        new_campaign.owner = user
        new_campaign.save()

    @classmethod
    def update(cls, campaign_dict, user):
        new_campaign = Campaign.objects.get(pk=int(campaign_dict.get('campaign_id')))
        new_campaign.name = campaign_dict['name']
        new_campaign.category = campaign_dict['category']
        new_campaign.conversion_ratio = campaign_dict['conversion_ratio']
        new_campaign.period = campaign_dict['period']
        new_campaign.money = campaign_dict['money']
        new_campaign.owner = user
        new_campaign.save()

    def __str__(self):
        return self.name

