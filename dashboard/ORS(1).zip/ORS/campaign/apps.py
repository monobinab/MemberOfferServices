from django.apps import AppConfig


class CampaignConfig(AppConfig):
    name = 'campaign'
