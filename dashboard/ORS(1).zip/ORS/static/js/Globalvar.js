var APIvar = {
	"serverIp": "http://localhost:8000"
}
