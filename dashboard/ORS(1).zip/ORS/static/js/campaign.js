var Campaign = {
	Constructor : function(){
		this.init = Campaign.init;
		this.Edit = Campaign.Edit;
		this.tableOptions = function(columns){
			this.paging = true;
			this.ajax = {};
			this.ajax.dataSrc = "";
			this.columns = columns;
		}
		
	},
	init : function(){
		$("#creteCampaign").on("click",function(){
			$("#campaignModal").modal('show');
		});
		
		
		$("#saveCampaign").on("click",function(event){
			event.preventDefault();
			var dataObj = {};
			if($("#campaignName").val() != null && $("#campaignName").val() != "" && $("#campaignName").val() != "undefined" )
				dataObj.name = $("#campaignName").val();
			if($("#money").val() != null && $("#money").val() != "" && $("#money").val() != "undefined" )
				dataObj.money = $("#money").val();
			if($("#category").val() != null && $("#category").val() != "" && $("#category").val() != "undefined" )
				dataObj.category = $("#category").val();
			if($("#conversionratio").val() != null && $("#conversionratio").val() != "" && $("#conversionratio").val() != "undefined" )
				dataObj.conversion_ratio = $("#conversionratio").val();
			if($("#period").val() != null && $("#period").val() != "" && $("#period").val() != "undefined" )
				dataObj.period = $("#period").val();
			$.ajax({
				headers: {"authorization":"Token b760b52fc2862f37fea29c43caf2fd56b93679fd"},
				url : APIvar.serverIp + "/api/campaign/",
				type : "POST",
				contentType: "application/json",
				data: JSON.stringify(dataObj),
				success: function(data){
					$("#campaignModal").modal('hide');
					alert(data);
				},
				error: function(error){
					alert("Something went wrong please try again later. "+error.statusText);
				}
			})
			
		})

		$("#campaignTable").DataTable({
			ajax:{
				"url": APIvar.serverIp+"/api/campaign/",
				"headers":{"authorization":"Token b760b52fc2862f37fea29c43caf2fd56b93679fd"},
				"data":function(data){
					return data.data;
				},
				"error": function(error){
					alert("Error"+error.statusText);
				}
			},
			columns: [
				{ data : 'name'
				},
				{ data : 'money'
				},
				{ data : 'category'
				},
				{ data : 'conversion_ratio' 
				},
				{ data : 'period'
				},
				{ data : null,
				  render : function(data){
					return "<button class='btn btn-table' onclick='GlobalVar.Campaign.Edit("+data.id+")'> <i class='icon-edit icon-size'> </i> </button> <button class='btn btn-table'> <i class='icon-trash icon-size'> </i> </button>"
				  }
				}
			]
		})
	},
	Edit : function(id){
		$.ajax({
			headers:{"authorization":"Token b760b52fc2862f37fea29c43caf2fd56b93679fd"},
			type:"GET",
			url: APIvar.serverIp+"/api/campaign/"+id,
				success:function(data){
					$("#campaignId").val(data.data.id);
					$("#campaignName").val(data.data.name);
					$("#money").val(data.data.money);
					$("#category").val(data.data.category);
					$("#conversionratio").val(data.data.conversion_ratio);
					$("#period").val(data.data.period);
					
					$("#campaignModal").modal("show");
				},
				error: function(error){
					alert("Error"+error.statusText);
				}
		})
	}
}